#! /bin/bash

export XAUTHORITY=~/.Xauthority
export DISPLAY=:0
export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/1000/bus"

BATT_STATE=$1
BATT_LVL=$(acpi -b | grep "Battery 0" | grep -P -o '[0-9]+(?=%)')

case "$BATT_STATE" in 
	1) /usr/bin/notify-send "Charging" "$BATT_LVL% of battery charged";;
	0) /usr/bin/notify-send "Discharging" "$BATT_LVL% of battery charged";;
esac
