#! /bin/bash

export DISPLAY=:0
export DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/1000/bus"

WARN_LVL=20
CRIT_LVL=5
BAT_DISCH=$(acpi -b | grep "Battery 0"| grep -c "Discharging")
BAT_LVL=$(acpi -b | grep "Battery 0"| grep -P -o '[0-9]+(?=%)')

FULL_FILE='/tmp/batt_full'
EMPT_FILE='/tmp/batt_empt'
CRIT_FILE='/tmp/batt_crit'

if [ $BAT_DISCH -eq 1 ] && [ -f $FULL_FILE ];
then
	rm $FULL_FILE
elif [ $BAT_DISCH -eq 0 ] && [ -f $EMPT_FILE ];
then
	rm $EMPT_FILE
fi

if [ $BAT_LVL -ge 79 ] && [ $BAT_DISCH -eq 0 ] && [ ! -f $FULL_FILE ];
then 
	/usr/bin/notify-send "Battery Charged" "You may unplug your charger!"
	wall "Battery charged! You may want to unplug your computer"
	touch $FULL_FILE
elif [ $BAT_LVL -le $WARN_LVL ] && [ $BAT_DISCH -eq 1 ] && [ ! -f $EMPT_FILE ];
then 
	/usr/bin/notify-send "Low Battery: $BAT_LVL" "You might want to plug your charger!" -u critical
	wall "LOW BATTERY! You might want to plug your charger"
	touch $EMPT_FILE
fi

